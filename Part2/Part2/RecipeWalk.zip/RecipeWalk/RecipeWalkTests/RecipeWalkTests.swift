//
//  RecipeWalkTests.swift
//  RecipeWalkTests
//
//  Created by nel on 2025-11-25.
//

import Testing
@testable import RecipeWalk

struct RecipeWalkTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
